# TAGS

![version][hoes_tags]


[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/oracle-quickstart/oci-arch-best-practices/tree/main/modules/tags/tags.zip)


Tags can help on provide an orthogonal perpective of the services that you have deployed. However indepdendent of the CSP or even rpoject is one of the most renagated contruct and also one that brings relevant lacks management, cost control troubleshooting and also simplification on how to improve security because can also be evaluated on policy.

Here will be preovided the most common basic perspectives that we can observe in cloud deployments. Very important can be leverage the usage of defined tags once we talk on control we can let open to all and any person define in create time what name and values to apply in scale this can became also in a lack of control.
We can use the name spaces to be our perspective and the tags what we will look the each value the label.

## NAME SPACE
* automation
* finance
* operation
* security

## TAGS

NameSpace      | TAGS
-------------- | --------------
Automation     | off_hours_flag
Automation     | deprovision_date
Automation     | stop_action_time
Automation     | start_action_time
Finance        | active_hours
Finance        | owner
Finance        | project
Operation      | application_name
Operation      | application_id
Operation      | resource_layer
Operation      | app_deployment_model
Operation      | environment_name
Operation      | target_compartment
Security       | confidenciality
Security       | compliance_name


<!-- Markdown link & dfns -->
[hoes_tags]: https://img.shields.io/badge/hoes_tags-v1.0-brightgreen